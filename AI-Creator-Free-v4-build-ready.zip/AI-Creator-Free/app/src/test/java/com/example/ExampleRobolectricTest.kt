package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.ContentSafetyGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context and verify safety guard`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AI Creative Studio", appName)

        val (safeValid, _) = ContentSafetyGuard.validatePrompt("30-second luxury watch commercial in rainy Tokyo")
        assertTrue(safeValid)
    }
}
