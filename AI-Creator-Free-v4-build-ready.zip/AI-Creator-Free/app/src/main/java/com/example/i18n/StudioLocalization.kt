package com.example.i18n

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.LayoutDirection
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Currency
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// Sections 17–21, 26–31, 40, 51–53: Global Multilingual & Locale Architecture (19 Supported Languages + True RTL)
enum class StudioLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String,
    val isRtl: Boolean = false,
    val defaultCurrency: String = "USD",
    val localeTag: String = "en-US"
) {
    EN("en", "English", "English", false, "USD", "en-US"),
    TR("tr", "Türkçe", "Turkish", false, "USD", "tr-TR"),
    DE("de", "Deutsch", "German", false, "EUR", "de-DE"),
    FR("fr", "Français", "French", false, "EUR", "fr-FR"),
    ES("es", "Español", "Spanish", false, "EUR", "es-ES"),
    IT("it", "Italiano", "Italian", false, "EUR", "it-IT"),
    PT("pt", "Português", "Portuguese", false, "EUR", "pt-PT"),
    NL("nl", "Nederlands", "Dutch", false, "EUR", "nl-NL"),
    AR("ar", "العربية", "Arabic", true, "USD", "ar-SA"),
    HE("he", "עברית", "Hebrew", true, "USD", "he-IL"),
    HI("hi", "हिन्दी", "Hindi", false, "USD", "hi-IN"),
    ID("id", "Bahasa Indonesia", "Indonesian", false, "USD", "id-ID"),
    JA("ja", "日本語", "Japanese", false, "JPY", "ja-JP"),
    KO("ko", "한국어", "Korean", false, "USD", "ko-KR"),
    ZH_CN("zh-CN", "简体中文", "Chinese Simplified", false, "USD", "zh-CN"),
    ZH_TW("zh-TW", "繁體中文", "Chinese Traditional", false, "USD", "zh-TW"),
    RU("ru", "Русский", "Russian", false, "USD", "ru-RU"),
    UK("uk", "Українська", "Ukrainian", false, "USD", "uk-UA"),
    PL("pl", "Polski", "Polish", false, "EUR", "pl-PL");

    val layoutDirection: LayoutDirection
        get() = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    companion object {
        fun detectFromSystem(): StudioLanguage {
            val sysLang = Locale.getDefault().language.lowercase(Locale.ROOT)
            val sysCountry = Locale.getDefault().country.uppercase(Locale.ROOT)
            if (sysLang == "zh") {
                return if (sysCountry == "TW" || sysCountry == "HK") ZH_TW else ZH_CN
            }
            return entries.find { it.code.equals(sysLang, ignoreCase = true) } ?: EN
        }
    }
}

enum class StudioCurrency(val code: String, val symbol: String, val rateFromUsd: Double) {
    USD("USD", "$", 1.0),
    EUR("EUR", "€", 0.92),
    GBP("GBP", "£", 0.79),
    CAD("CAD", "CA$", 1.36),
    AUD("AUD", "A$", 1.52),
    JPY("JPY", "¥", 154.0),
    CHF("CHF", "CHF ", 0.88)
}

enum class UnitSystem(val label: String) {
    METRIC("Metric (km, kg, °C)"),
    IMPERIAL("Imperial (miles, lbs, °F)")
}

enum class StudioExperienceMode(val label: String) {
    BEGINNER("Simple / Beginner Mode"),
    CREATOR("Creator Mode"),
    PRO("Pro Studio Mode")
}

data class GlossaryEntry(
    val id: Long = System.currentTimeMillis(),
    val term: String,
    val preferredTranslation: String,
    val doNotTranslate: Boolean = true
)

class StudioLocalizer(val language: StudioLanguage) {
    fun t(key: String, params: Map<String, String> = emptyMap()): String {
        val raw = translations[language]?.get(key)
            ?: translations[StudioLanguage.EN]?.get(key)
            ?: key.substringAfterLast('.').replaceFirstChar { it.uppercase() }
        var output = raw
        params.forEach { (k, v) ->
            output = output.replace("{$k}", v)
        }
        return output
    }

    fun formatCurrency(usdAmount: Double, currency: StudioCurrency): String {
        val converted = usdAmount * currency.rateFromUsd
        return try {
            val loc = Locale.forLanguageTag(language.localeTag)
            val fmt = NumberFormat.getCurrencyInstance(loc)
            fmt.currency = Currency.getInstance(currency.code)
            if (currency == StudioCurrency.JPY) {
                fmt.maximumFractionDigits = 0
            }
            fmt.format(converted)
        } catch (_: Exception) {
            if (currency == StudioCurrency.JPY) "${currency.symbol}${converted.toInt()}"
            else "${currency.symbol}${"%.2f".format(converted)}"
        }
    }

    fun formatDateTime(epochMillis: Long, use24Hour: Boolean = true): String {
        val loc = Locale.forLanguageTag(language.localeTag)
        val pattern = if (use24Hour) "dd/MM/yyyy HH:mm" else "MM/dd/yyyy hh:mm a"
        val sdf = SimpleDateFormat(pattern, loc)
        sdf.timeZone = TimeZone.getDefault()
        return sdf.format(Date(epochMillis))
    }

    companion object {
        private val enMap = mapOf(
            "common.save" to "Save",
            "common.saved" to "Saved",
            "common.saving" to "Saving...",
            "common.unsaved" to "Unsaved changes",
            "common.cancel" to "Cancel",
            "common.generate" to "Generate",
            "common.createVideo" to "Create Video",
            "common.tryAgain" to "Try Again",
            "common.preview" to "Preview",
            "common.apply" to "Apply",
            "common.export" to "Export",
            "common.share" to "Share",
            "common.translate" to "Translate",
            "common.enhance" to "Enhance",
            "common.regenerate" to "Regenerate",
            "landing.heroTitle" to "Create. Direct. Edit. With AI.",
            "landing.heroSubtitle" to "Turn your ideas into professional video, voice, music and content — all in one creative studio.",
            "landing.startCreating" to "Start Creating",
            "landing.exploreStudio" to "Explore Studio",
            "landing.watchDemo" to "Watch Demo",
            "dashboard.title" to "Create anything with AI.",
            "dashboard.promptPlaceholder" to "What do you want to create? (e.g., Create a 30-second premium coffee advertisement...)",
            "dashboard.recentProjects" to "Recent Projects",
            "nav.home" to "Home",
            "nav.ai_director" to "AI Director",
            "nav.video" to "Video",
            "nav.image" to "Image",
            "nav.voice" to "Voice & Live",
            "nav.music" to "Music (Lyria 3)",
            "nav.sound_effects" to "Sound Effects",
            "nav.studio" to "Studio Timeline",
            "nav.projects" to "Projects",
            "nav.assets" to "Assets",
            "nav.templates" to "Templates",
            "nav.brand_kit" to "Brand Kit",
            "nav.ai_assistant" to "AI Assistant",
            "nav.history" to "History",
            "nav.exports" to "Exports",
            "nav.billing" to "Billing",
            "nav.settings" to "Settings & Global",
            "editor.timeline" to "Multi-Track Timeline",
            "editor.export" to "Master Export",
            "billing.upgrade" to "Upgrade Plan",
            "empty.noProjects" to "No projects yet",
            "empty.createFirst" to "Create your first AI video and start building.",
            "cmd.createVideo" to "Create Video",
            "cmd.createVoice" to "Generate Voice",
            "cmd.createMusic" to "Generate Music (Lyria 3)",
            "cmd.exportProject" to "Export Project",
            "generation.errors.failed" to "Generation could not be completed. Credits were safely preserved."
        )

        private val trMap = mapOf(
            "common.save" to "Kaydet",
            "common.saved" to "Kaydedildi",
            "common.saving" to "Kaydediliyor...",
            "common.unsaved" to "Kaydedilmemiş değişiklikler",
            "common.cancel" to "İptal",
            "common.generate" to "Oluştur",
            "common.createVideo" to "Video Oluştur",
            "common.tryAgain" to "Tekrar Dene",
            "common.preview" to "Önizle",
            "common.apply" to "Uygula",
            "common.export" to "Dışa Aktar",
            "common.share" to "Paylaş",
            "common.translate" to "Çevir",
            "common.enhance" to "Geliştir",
            "common.regenerate" to "Yeniden Üret",
            "landing.heroTitle" to "Yarat. Yönet. Kurgu Yap. Yapay Zeka İle.",
            "landing.heroSubtitle" to "Fikirlerinizi tek bir yaratıcı stüdyoda profesyonel video, ses, müzik ve içeriğe dönüştürün.",
            "landing.startCreating" to "Üretmeye Başla",
            "landing.exploreStudio" to "Stüdyoyu Keşfet",
            "landing.watchDemo" to "Demoyu İzle",
            "dashboard.title" to "Yapay zeka ile her şeyi üretin.",
            "dashboard.promptPlaceholder" to "Ne oluşturmak istiyorsunuz? (Örn: 30 saniyelik premium bir kahve reklamı oluştur...)",
            "dashboard.recentProjects" to "Son Projeler",
            "nav.home" to "Ana Sayfa",
            "nav.ai_director" to "AI Yönetmen",
            "nav.video" to "Video (Veo 3.1)",
            "nav.image" to "Görsel",
            "nav.voice" to "Ses & Canlı",
            "nav.music" to "Müzik (Lyria 3)",
            "nav.sound_effects" to "Ses Efektleri",
            "nav.studio" to "Stüdyo Timeline",
            "nav.projects" to "Projeler",
            "nav.assets" to "Varlıklar",
            "nav.templates" to "Şablonlar",
            "nav.brand_kit" to "Marka Kiti",
            "nav.ai_assistant" to "AI Asistan",
            "nav.history" to "Geçmiş",
            "nav.exports" to "Dışa Aktarımlar",
            "nav.billing" to "Faturalandırma",
            "nav.settings" to "Ayarlar & Dil",
            "editor.timeline" to "Çok Kanallı Timeline",
            "editor.export" to "Ana Dışa Aktarım",
            "billing.upgrade" to "Planı Yükselt",
            "empty.noProjects" to "Henüz proje yok",
            "empty.createFirst" to "İlk AI videonuzu oluşturun ve üretime başlayın.",
            "cmd.createVideo" to "Video oluştur",
            "cmd.createVoice" to "Ses oluştur",
            "cmd.createMusic" to "Müzik oluştur",
            "cmd.exportProject" to "Projeyi dışa aktar",
            "generation.errors.failed" to "Üretim tamamlanamadı. Krediniz güvenli şekilde korundu."
        )

        private val deMap = mapOf(
            "common.save" to "Speichern",
            "common.saved" to "Gespeichert",
            "common.saving" to "Speichert...",
            "common.generate" to "Generieren",
            "common.createVideo" to "Video erstellen",
            "common.export" to "Exportieren",
            "common.translate" to "Übersetzen",
            "landing.heroTitle" to "Erstellen. Regie führen. Schneiden. Mit KI.",
            "landing.heroSubtitle" to "Verwandeln Sie Ihre Ideen in professionelle Videos, Stimmen, Musik und Inhalte — alles in einem Kreativstudio.",
            "landing.startCreating" to "Jetzt starten",
            "landing.exploreStudio" to "Studio entdecken",
            "dashboard.title" to "Erstelle alles mit KI.",
            "dashboard.promptPlaceholder" to "Erstelle einen 30-sekündigen Premium-Werbespot für eine Kaffeemarke...",
            "nav.home" to "Startseite",
            "nav.ai_director" to "KI-Regisseur",
            "nav.video" to "Video",
            "nav.voice" to "Stimme",
            "nav.music" to "Musik",
            "nav.studio" to "Studio-Timeline",
            "cmd.createVideo" to "Video erstellen",
            "cmd.createVoice" to "Stimme erstellen",
            "cmd.createMusic" to "Musik erstellen",
            "cmd.exportProject" to "Projekt exportieren"
        )

        private val arMap = mapOf(
            "common.save" to "حفظ",
            "common.saved" to "تم الحفظ",
            "common.saving" to "جاري الحفظ...",
            "common.generate" to "توليد",
            "common.createVideo" to "إنشاء فيديو",
            "common.export" to "تصدير",
            "common.translate" to "ترجمة",
            "landing.heroTitle" to "ابتكر. أخرج. حرر. بالذكاء الاصطناعي.",
            "landing.heroSubtitle" to "حوّل أفكارك إلى فيديو احترافي وصوت وموسيقى ومحتوى متكامل في استوديو إبداعي واحد.",
            "landing.startCreating" to "ابدأ الإنشاء",
            "landing.exploreStudio" to "استكشف الاستوديو",
            "dashboard.title" to "اصنع أي شيء بالذكاء الاصطناعي.",
            "dashboard.promptPlaceholder" to "ماذا تريد أن تصنع؟ (مثال: إعلان سينمائي لمدة 30 ثانية...)",
            "nav.home" to "الرئيسية",
            "nav.ai_director" to "المخرج الذكي",
            "nav.video" to "فيديو",
            "nav.image" to "صورة",
            "nav.voice" to "صوت ومحادثة",
            "nav.music" to "موسيقى",
            "nav.studio" to "الخط الزمني",
            "nav.projects" to "المشاريع",
            "nav.settings" to "الإعدادات واللغات",
            "cmd.createVideo" to "إنشاء فيديو",
            "cmd.createVoice" to "توليد صوت",
            "cmd.createMusic" to "توليد موسيقى",
            "cmd.exportProject" to "تصدير المشروع"
        )

        private val heMap = mapOf(
            "common.save" to "שמור",
            "common.saved" to "נשמר",
            "common.generate" to "צור",
            "common.createVideo" to "צור וידאו",
            "common.export" to "ייצוא",
            "landing.heroTitle" to "ליצור. לביים. לערוך. עם AI.",
            "landing.startCreating" to "התחל ליצור",
            "dashboard.title" to "צור הכל באמצעות AI.",
            "nav.home" to "בית",
            "nav.ai_director" to "במאי AI",
            "nav.studio" to "ציר זמן"
        )

        private val jaMap = mapOf(
            "common.save" to "保存",
            "common.saved" to "保存済み",
            "common.generate" to "生成する",
            "common.createVideo" to "動画を作成",
            "common.export" to "書き出し",
            "common.translate" to "翻訳",
            "landing.heroTitle" to "AIで創造、監督、編集。",
            "landing.heroSubtitle" to "アイデアをプロ品質の映像、音声、音楽へと昇華させるオールインワン制作スタジオ。",
            "landing.startCreating" to "制作を始める",
            "dashboard.title" to "AIであらゆる作品を創造。",
            "nav.home" to "ホーム",
            "nav.ai_director" to "AIディレクター",
            "nav.video" to "動画 (Veo 3.1)",
            "nav.voice" to "音声・ライブ会話",
            "nav.music" to "音楽 (Lyria 3)",
            "nav.studio" to "タイムライン"
        )

        private val translations: Map<StudioLanguage, Map<String, String>> = mapOf(
            StudioLanguage.EN to enMap,
            StudioLanguage.TR to trMap,
            StudioLanguage.DE to deMap,
            StudioLanguage.AR to arMap,
            StudioLanguage.HE to heMap,
            StudioLanguage.JA to jaMap
        )
    }
}

val LocalStudioLocalizer = compositionLocalOf { StudioLocalizer(StudioLanguage.EN) }
