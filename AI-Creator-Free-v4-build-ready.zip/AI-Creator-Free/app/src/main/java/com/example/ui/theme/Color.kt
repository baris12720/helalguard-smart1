package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Dark-First Creative Software Palette (Section 49)
val StudioObsidianBg = Color(0xFF0A0B0F)       // Deepest neutral obsidian background
val StudioSurface = Color(0xFF12141C)          // Primary panel surface
val StudioSurfaceElevated = Color(0xFF191C26)  // Card / Track surface
val StudioSurfaceHigh = Color(0xFF222634)      // Interactive chip / hover surface
val StudioBorderSubtle = Color(0xFF282D3E)     // Subtle 1dp structural border

// Single Primary Accent + Functional Track Accents
val StudioPrimaryIndigo = Color(0xFF6366F1)    // Primary studio accent (Electric Indigo)
val StudioPrimaryBright = Color(0xFF818CF8)    // Highlighted Indigo
val StudioPrimaryContainer = Color(0xFF1E2246) // Subtle Indigo container

val StudioCyanAccent = Color(0xFF06B6D4)       // Voice / Audio track & AI Director highlight
val StudioEmeraldSuccess = Color(0xFF10B981)   // Music track / Completed job / Quality pass
val StudioAmberWarning = Color(0xFFF59E0B)     // SFX track / Credits warning / Queued job
val StudioRoseDanger = Color(0xFFF43F5E)       // Recording / Viral Mode / Error state
val StudioVioletSub = Color(0xFFA855F7)        // Subtitle / Storyboard track accent

val StudioTextPrimary = Color(0xFFF3F4F6)      // High-contrast crisp white-gray
val StudioTextSecondary = Color(0xFF9CA3AF)    // Muted technical label gray
val StudioTextMuted = Color(0xFF6B7280)        // Disabled / Timecode ruler text
