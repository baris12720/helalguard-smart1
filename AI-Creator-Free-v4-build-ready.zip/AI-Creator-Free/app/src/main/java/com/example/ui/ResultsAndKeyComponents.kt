package com.example.ui

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.ai.ApiKeyStore
import com.example.ai.GeneratedMediaStore
import com.example.data.GenerationJobEntity
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel
import java.io.File

/** Lets every user paste their own Gemini API key, so the app owner does not pay for usage. */
@Composable
fun ApiKeyCard(isTr: Boolean) {
    val context = LocalContext.current
    val hasKey = ApiKeyStore.hasUserKey || ApiKeyStore.hasBuildKey
    var editing by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }

    if (hasKey && !editing) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(StudioSurface)
                .border(1.dp, StudioBorderSubtle, RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StudioEmeraldSuccess, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                text = if (isTr) "Yapay zeka etkin" + if (ApiKeyStore.hasUserKey) " (kendi anahtarın)" else ""
                else "AI enabled" + if (ApiKeyStore.hasUserKey) " (your own key)" else "",
                style = MaterialTheme.typography.bodySmall,
                color = StudioTextPrimary,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            TextButton(onClick = { editing = true }, modifier = Modifier.testTag("api_key_change_button")) {
                Text(if (isTr) "Değiştir" else "Change")
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioSurface)
                .border(1.dp, StudioAmberWarning.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = if (isTr) "Gerçek yapay zeka için Gemini API anahtarını gir" else "Enter your Gemini API key for real AI output",
                style = MaterialTheme.typography.titleSmall,
                color = StudioTextPrimary
            )
            Text(
                text = if (isTr) "Anahtar Android Keystore ile şifrelenerek bu cihazda tutulur; geliştirici anahtarınıza erişmez."
                else "Your key is encrypted with Android Keystore and stays on this device; the developer never sees it.",
                style = MaterialTheme.typography.bodySmall,
                color = StudioTextSecondary
            )
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                label = { Text("Gemini API key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth().testTag("api_key_input")
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        ApiKeyStore.saveUserKey(draft)
                        draft = ""
                        editing = false
                    },
                    enabled = draft.isNotBlank(),
                    modifier = Modifier.testTag("api_key_save_button")
                ) { Text(if (isTr) "Kaydet" else "Save") }
                TextButton(onClick = {
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                    }
                }) { Text(if (isTr) "Anahtar al" else "Get a key") }
                if (ApiKeyStore.hasUserKey) {
                    TextButton(onClick = { ApiKeyStore.clearUserKey(); editing = false }) {
                        Text(if (isTr) "Sil" else "Remove")
                    }
                }
                if (hasKey) {
                    TextButton(onClick = { editing = false; draft = "" }) { Text(if (isTr) "Vazgeç" else "Cancel") }
                }
            }
        }
    }
}

/** Recently generated audio / images that were saved on device, with play + share. */
@Composable
fun ResultsShelf(jobs: List<GenerationJobEntity>, isTr: Boolean) {
    val context = LocalContext.current
    var playingId by remember { mutableStateOf<Long?>(null) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }
    DisposableEffect(Unit) {
        onDispose {
            try { player[0]?.release() } catch (_: Exception) { }
            player[0] = null
        }
    }

    val shelf = remember(jobs) {
        jobs.filter { it.status == "COMPLETED" && it.jobType in setOf("MUSIC", "IMAGE", "VOICE", "VIDEO", "EXPORT") }
            .sortedByDescending { it.createdAt }
            .mapNotNull { job -> GeneratedMediaStore.fileFor(context, job.id)?.let { job to it } }
            .take(12)
    }

    fun togglePlay(jobId: Long, file: File) {
        if (playingId == jobId) {
            try { player[0]?.release() } catch (_: Exception) { }
            player[0] = null
            playingId = null
            return
        }
        try { player[0]?.release() } catch (_: Exception) { }
        val mp = MediaPlayer()
        try {
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener { finished ->
                try { finished.release() } catch (_: Exception) { }
                player[0] = null
                playingId = null
            }
            mp.prepare()
            mp.start()
            player[0] = mp
            playingId = jobId
        } catch (_: Exception) {
            try { mp.release() } catch (_: Exception) { }
            player[0] = null
            playingId = null
        }
    }

    if (shelf.isNotEmpty()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = if (isTr) "SON ÜRETİMLERİN" else "YOUR LATEST CREATIONS",
                style = MaterialTheme.typography.labelMedium,
                color = StudioTextSecondary
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(shelf, key = { it.first.id }) { entry ->
                    val job = entry.first
                    val file = entry.second
                    val isAudio = GeneratedMediaStore.isAudio(file)
                    val isVideo = GeneratedMediaStore.mimeOf(file) == "video/mp4"
                    Column(
                        modifier = Modifier
                            .width(150.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(StudioSurface)
                            .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(84.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(StudioPrimaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isAudio) {
                                IconButton(onClick = { togglePlay(job.id, file) }) {
                                    Icon(
                                        imageVector = if (playingId == job.id) Icons.Default.Stop else Icons.Default.PlayArrow,
                                        contentDescription = if (playingId == job.id) "Stop" else "Play",
                                        tint = StudioPrimaryBright,
                                        modifier = Modifier.size(38.dp)
                                    )
                                }
                            } else if (isVideo) {
                                Icon(
                                    Icons.Default.Movie,
                                    contentDescription = "Video",
                                    tint = StudioPrimaryBright,
                                    modifier = Modifier.size(42.dp)
                                )
                            } else {
                                AsyncImage(
                                    model = file,
                                    contentDescription = job.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                        Text(
                            text = job.title,
                            style = MaterialTheme.typography.labelLarge,
                            color = StudioTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        OutlinedButton(
                            onClick = { shareFile(context, file) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (isTr) "Paylaş / indir" else "Share / save", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

private fun shareFile(context: Context, file: File) {
    try {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = GeneratedMediaStore.mimeOf(file)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
    }
}

/** Text -> lyrics -> sung track: pick text (typed or .txt), genre, length, press create. */
@Composable
fun TextToSongCard(viewModel: StudioViewModel) {
    val context = LocalContext.current
    val lang by viewModel.selectedLanguage.collectAsState()
    val isTr = lang.code == "tr"
    var text by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("Pop") }
    var durationSec by remember { mutableIntStateOf(30) }
    val genres = listOf("Pop", "Rock", "Rap", "Arabesk", "Folk", "Acoustic", "Electronic", "Jazz", "Lo-Fi", "Classical")

    val txtPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    text = stream.bufferedReader().readText().take(4000)
                }
            } catch (_: Exception) {
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(StudioSurface)
            .border(1.dp, StudioPrimaryIndigo.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Lyrics, contentDescription = null, tint = StudioPrimaryBright)
            Spacer(Modifier.width(8.dp))
            Text(
                text = if (isTr) "Metinden Şarkı" else "Text to Song",
                style = MaterialTheme.typography.titleMedium,
                color = StudioTextPrimary
            )
        }
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(4000) },
            label = { Text(if (isTr) "Metnin (şiir, hikâye, birkaç cümle...)" else "Your text (poem, story, a few lines...)") },
            minLines = 4,
            maxLines = 8,
            modifier = Modifier.fillMaxWidth().testTag("text_to_song_input")
        )
        OutlinedButton(onClick = { txtPicker.launch("text/plain") }) {
            Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(if (isTr) ".txt dosyası yükle" else "Import .txt file")
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(genres) { g ->
                FilterChip(selected = genre == g, onClick = { genre = g }, label = { Text(g) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = durationSec == 30, onClick = { durationSec = 30 }, label = { Text(if (isTr) "30 sn" else "30 s") })
            FilterChip(selected = durationSec == 60, onClick = { durationSec = 60 }, label = { Text(if (isTr) "1 dk" else "1 min") })
        }
        Button(
            onClick = { viewModel.createSongFromText(text, genre, durationSec) },
            enabled = text.isNotBlank(),
            modifier = Modifier.fillMaxWidth().testTag("text_to_song_create_button")
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(if (isTr) "Şarkıyı oluştur" else "Create song")
        }
    }
}
