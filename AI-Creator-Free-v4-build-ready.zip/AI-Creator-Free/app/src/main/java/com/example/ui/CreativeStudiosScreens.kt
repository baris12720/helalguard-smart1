package com.example.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.CharacterProfileEntity
import com.example.i18n.LocalStudioLocalizer
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoStudioScreen(viewModel: StudioViewModel) {
    val i18n = LocalStudioLocalizer.current
    val uploadedPhotoUri by viewModel.uploadedPhotoUri.collectAsState()

    var mode by remember { mutableStateOf("Text to Video") }
    var prompt by remember { mutableStateOf("Sleek autonomous coupe gliding through rainy neon Tokyo at midnight, water droplets on anamorphic lens") }
    // Veo 3.1 strict landscape (16:9) or portrait (9:16) aspect ratio
    var aspectRatio by remember { mutableStateOf("16:9") }
    var resolution by remember { mutableStateOf("1080p") }
    var fps by remember { mutableIntStateOf(24) }
    var durationSec by remember { mutableIntStateOf(10) }
    var camera by remember { mutableStateOf("Tracking") }
    var lens by remember { mutableStateOf("35mm") }
    var lighting by remember { mutableStateOf("Neon") }
    var characterConsistency by remember { mutableStateOf(true) }
    var styleConsistency by remember { mutableStateOf(true) }
    var selectedVariant by remember { mutableIntStateOf(1) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.onPhotoSelectedFromPicker(uri)
            mode = "Image to Video"
        }
    }

    val videoModes = listOf(
        "Text to Video", "Image to Video", "Script to Video", "Story to Video",
        "Video Extension", "Video Continuation", "Scene Regeneration", "Video Restyle"
    )
    val cameraOptions = listOf("Static", "Pan", "Tilt", "Dolly", "Zoom", "Tracking", "Handheld", "Drone", "Orbit", "Low Angle", "High Angle")
    val lensOptions = listOf("24mm", "35mm", "50mm", "85mm", "Telephoto")
    val lightingOptions = listOf("Natural", "Studio", "Cinematic", "Neon", "Golden Hour", "Dark", "High Contrast")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "AI VIDEO STUDIO • VEO 3.1 FAST GENERATE PREVIEW (16:9 & 9:16)",
                        style = MaterialTheme.typography.titleMedium,
                        color = StudioTextPrimary
                    )

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        videoModes.forEach { m ->
                            FilterChip(
                                selected = mode == m,
                                onClick = { mode = m },
                                label = { Text(m) }
                            )
                        }
                    }

                    // Upload Photo to Animate into Video (veo-3.1-generate-preview)
                    Surface(
                        color = StudioSurfaceElevated,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, StudioCyanAccent.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "ANIMATE PHOTO INTO VIDEO (VEO 3.1 FAST)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioCyanAccent
                                )
                                Text(
                                    text = if (uploadedPhotoUri != null) "Photo Attached: $uploadedPhotoUri" else "Upload a reference photo to animate with Veo 3.1 (16:9 or 9:16)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StudioTextSecondary
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (uploadedPhotoUri != null) {
                                    TextButton(onClick = { viewModel.clearUploadedPhoto() }) {
                                        Text("Clear", color = StudioRoseDanger)
                                    }
                                }
                                OutlinedButton(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier.testTag("upload_photo_for_veo_button")
                                ) {
                                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Upload Photo")
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        label = { Text("$mode Prompt (veo-3.1-generate-preview)") },
                        minLines = 2,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("video_studio_prompt_input")
                    )

                    // Aspect Ratio (Veo 16:9 Landscape & 9:16 Portrait highlighted), Resolution, FPS, Duration
                    Text("VEO 3.1 ASPECT RATIO (16:9 LANDSCAPE / 9:16 PORTRAIT), RESOLUTION & FPS", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("16:9" to "16:9 Landscape", "9:16" to "9:16 Portrait").forEach { (ar, label) ->
                            FilterChip(
                                selected = aspectRatio == ar,
                                onClick = { aspectRatio = ar },
                                label = { Text(label) }
                            )
                        }
                        listOf("720p", "1080p", "4K").forEach { res ->
                            FilterChip(selected = resolution == res, onClick = { resolution = res }, label = { Text(res) })
                        }
                        listOf(24, 25, 30, 60).forEach { f ->
                            FilterChip(selected = fps == f, onClick = { fps = f }, label = { Text("${f}fps") })
                        }
                        listOf(5, 10, 15, 30, 60).forEach { d ->
                            FilterChip(selected = durationSec == d, onClick = { durationSec = d }, label = { Text("${d} sec") })
                        }
                    }

                    // Camera Movement
                    Text("CAMERA MOVEMENT", style = MaterialTheme.typography.labelSmall, color = StudioPrimaryBright)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        cameraOptions.forEach { cam ->
                            FilterChip(selected = camera == cam, onClick = { camera = cam }, label = { Text(cam) })
                        }
                    }

                    // Lens & Lighting
                    Text("OPTICAL LENS & LIGHTING", style = MaterialTheme.typography.labelSmall, color = StudioEmeraldSuccess)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        lensOptions.forEach { l ->
                            FilterChip(selected = lens == l, onClick = { lens = l }, label = { Text(l) })
                        }
                        lightingOptions.forEach { light ->
                            FilterChip(selected = lighting == light, onClick = { lighting = light }, label = { Text(light) })
                        }
                    }

                    // Consistency Locks
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FilterChip(
                            selected = characterConsistency,
                            onClick = { characterConsistency = !characterConsistency },
                            label = { Text("Character Consistency Lock") },
                            leadingIcon = { Icon(Icons.Default.PersonPin, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                        FilterChip(
                            selected = styleConsistency,
                            onClick = { styleConsistency = !styleConsistency },
                            label = { Text("Style Consistency Lock") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                    }

                    // Multi-Variant Generation (Section 68)
                    Text("MULTI-VARIANT GENERATION (GENERATE 1 / 2 / 3)", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        (1..3).forEach { v ->
                            Surface(
                                color = if (selectedVariant == v) StudioPrimaryContainer else StudioSurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .border(
                                        1.dp,
                                        if (selectedVariant == v) StudioPrimaryIndigo else StudioBorderSubtle,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { selectedVariant = v }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("Variant $v", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                    Text("$camera • $lens", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.launchModalityGeneration(
                                jobType = "VIDEO",
                                title = "$mode ($aspectRatio • $camera, $lens)",
                                prompt = "$prompt [Model: veo-3.1-generate-preview, Camera: $camera, Lens: $lens, Lighting: $lighting, Ratio: $aspectRatio, FPS: $fps]",
                                resolutionOrFormat = "$resolution MP4 • $aspectRatio • ${fps}fps",
                                durationSec = durationSec,
                                creditCost = if (resolution == "4K") 24 else 14,
                                addToTimelineTrack = "VIDEO"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("generate_video_studio_button")
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${i18n.t("common.createVideo")} (Veo 3.1 • $aspectRatio)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ImageAndCharacterStudioScreen(
    viewModel: StudioViewModel,
    characters: List<CharacterProfileEntity>
) {
    val uploadedPhotoUri by viewModel.uploadedPhotoUri.collectAsState()
    var imageMode by remember { mutableStateOf("Create Image") } // Create Image vs Edit Image
    var imagePrompt by remember { mutableStateOf("Key storyboard frame: futuristic luxury roadster parked outside rain-drenched Neo-Tokyo opera house, 35mm anamorphic") }
    var aspectRatio by remember { mutableStateOf("16:9") }
    var styleLockRef by remember { mutableStateOf("Anamorphic Cyber-Noir (Obsidian + Indigo + Cyan)") }

    var newCharName by remember { mutableStateOf("") }
    var newCharAge by remember { mutableStateOf("30") }
    var newCharAppearance by remember { mutableStateOf("") }
    var newCharClothes by remember { mutableStateOf("") }
    var newCharPersonality by remember { mutableStateOf("") }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.onPhotoSelectedFromPicker(uri)
            imageMode = "Edit Image"
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Image Creation & Editing (`gemini-3.1-flash-image-preview`)
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "CREATE & EDIT IMAGES • GEMINI-3.1-FLASH-IMAGE-PREVIEW",
                        style = MaterialTheme.typography.titleMedium,
                        color = StudioTextPrimary
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Create Image", "Edit Image", "Inpaint / Outpaint", "Style Lock Reference").forEach { m ->
                            FilterChip(
                                selected = imageMode == m,
                                onClick = { imageMode = m },
                                label = { Text(m) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (uploadedPhotoUri != null) "Editing Reference: $uploadedPhotoUri" else "Optional: Attach an image to edit/restyle with gemini-3.1-flash-image-preview",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioCyanAccent,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.testTag("upload_image_for_edit_button")
                        ) {
                            Icon(Icons.Default.ImageSearch, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pick Image to Edit")
                        }
                    }

                    OutlinedTextField(
                        value = imagePrompt,
                        onValueChange = { imagePrompt = it },
                        label = { Text("$imageMode Prompt (gemini-3.1-flash-image-preview)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("16:9", "9:16", "1:1", "4:5").forEach { ar ->
                            FilterChip(selected = aspectRatio == ar, onClick = { aspectRatio = ar }, label = { Text(ar) })
                        }
                    }
                    OutlinedTextField(
                        value = styleLockRef,
                        onValueChange = { styleLockRef = it },
                        label = { Text("Style Lock Reference (Color Palette, Lighting, Texture, Mood)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            viewModel.launchModalityGeneration(
                                jobType = "IMAGE",
                                title = "$imageMode: ${imagePrompt.take(20)}",
                                prompt = "$imagePrompt | Mode: $imageMode | Style Lock: $styleLockRef",
                                resolutionOrFormat = "4K PNG • $aspectRatio",
                                durationSec = 5,
                                creditCost = 4,
                                addToTimelineTrack = "IMAGE"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_image_studio_button")
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("$imageMode with gemini-3.1-flash-image-preview (4 CR)")
                    }
                }
            }
        }

        // Section 6: Character Consistency Builder & Library
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("CHARACTER CONSISTENCY ENGINE & LIBRARY", style = MaterialTheme.typography.titleMedium, color = StudioCyanAccent)
                    Text(
                        text = "Define character visual DNA so AI preserves facial geometry, wardrobe, and demeanor across all scenes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioTextSecondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newCharName,
                            onValueChange = { newCharName = it },
                            label = { Text("Character Name") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = newCharAge,
                            onValueChange = { newCharAge = it },
                            label = { Text("Age") },
                            modifier = Modifier.width(90.dp)
                        )
                    }
                    OutlinedTextField(
                        value = newCharAppearance,
                        onValueChange = { newCharAppearance = it },
                        label = { Text("Appearance (Face, hair, distinctive traits)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newCharClothes,
                        onValueChange = { newCharClothes = it },
                        label = { Text("Signature Wardrobe / Clothes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newCharPersonality,
                        onValueChange = { newCharPersonality = it },
                        label = { Text("Personality & Acting Direction") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            viewModel.createCharacter(
                                name = newCharName.ifBlank { "Aria Sterling" },
                                age = newCharAge,
                                appearance = newCharAppearance.ifBlank { "Sharp emerald eyes, athletic silhouette" },
                                clothes = newCharClothes.ifBlank { "Matte obsidian flight jacket" },
                                personality = newCharPersonality.ifBlank { "Bold, charismatic lead" }
                            )
                            newCharName = ""
                            newCharAppearance = ""
                            newCharClothes = ""
                            newCharPersonality = ""
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("create_character_button")
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Character to Consistency Library")
                    }
                }
            }
        }

        items(characters, key = { it.id }) { charItem ->
            Surface(
                color = StudioSurfaceElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${charItem.name} (Age ${charItem.age})", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                        Text("CONSISTENCY ACTIVE", style = MaterialTheme.typography.labelSmall, color = StudioEmeraldSuccess)
                    }
                    Text("Appearance: ${charItem.appearance}", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                    Text("Wardrobe: ${charItem.clothes}", style = MaterialTheme.typography.bodySmall, color = StudioCyanAccent)
                    Text("Persona: ${charItem.personality}", style = MaterialTheme.typography.labelSmall, color = StudioTextMuted)
                }
            }
        }
    }
}

@Composable
fun VoiceStudioScreen(viewModel: StudioViewModel) {
    val liveVoiceTurns by viewModel.liveVoiceTurns.collectAsState()
    val isRecordingMic by viewModel.isRecordingMic.collectAsState()
    val lastTranscribed by viewModel.lastTranscribedText.collectAsState()

    var category by remember { mutableStateOf("Cinematic") }
    var selectedRegion by remember { mutableStateOf("English (US)") }
    var selectedComparisonVoice by remember { mutableStateOf("Voice A: Marcus (Deep Cinema)") }
    var emotion by remember { mutableStateOf("serious") }
    var speed by remember { mutableFloatStateOf(1.0f) }
    var pitch by remember { mutableFloatStateOf(0.95f) }
    var pauseMs by remember { mutableIntStateOf(250) }
    var scriptText by remember {
        mutableStateOf("Some journeys are measured in heartbeats, not hours. Experience Chronos Noir.")
    }
    var liveInputPrompt by remember { mutableStateOf("") }

    // Section 9: Consent-Verified Voice Cloning state
    var cloneProfileName by remember { mutableStateOf("") }
    var consentConfirmed by remember { mutableStateOf(false) }
    var clonedProfiles by remember {
        mutableStateOf(listOf("Founder Studio Clone (Verified Consent #8841)"))
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.recordAndTranscribeMicrophone { transcribed ->
            scriptText = transcribed
        }
    }

    val liveMicPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.startLiveVoiceConversationTurn(liveInputPrompt)
    }

    val categories = listOf("Narrator", "Commercial", "Cinematic", "Storytelling", "Podcast", "News", "Character", "Documentary")
    val regionalVoices = listOf(
        "English (US)", "English (UK)", "English (Australia)",
        "Türkçe (TR)", "Deutsch (DE)", "Español (Spain)", "Español (Mexico)",
        "Português (Brazil)", "Português (Portugal)", "العربية (MENA)", "日本語 (JP)"
    )
    val voiceComparisonList = listOf(
        Triple("Voice A: Marcus (Deep Cinema)", 0.96f, 0.88f),
        Triple("Voice B: Elena (Warm Storyteller)", 1.02f, 1.06f),
        Triple("Voice C: Kai (High-Energy Commercial)", 1.12f, 1.00f)
    )
    val emotions = listOf("happy", "sad", "angry", "excited", "calm", "serious", "mysterious", "energetic")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Real-Time Voice Conversation with `gemini-3.8-live` + Microphone Transcription (`gemini-3.5-transcribe`)
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioCyanAccent.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = StudioCyanAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("REAL-TIME VOICE CONVERSATION • GEMINI-3.8-LIVE", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                        }
                        Surface(color = StudioPrimaryContainer, shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = if (isRecordingMic) "LISTENING..." else "LIVE API READY",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isRecordingMic) StudioRoseDanger else StudioEmeraldSuccess,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Text(
                        text = "Have a real-time spoken conversation with the studio using `gemini-3.8-live`, or transcribe microphone voice notes with `gemini-3.5-transcribe`.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioTextSecondary
                    )

                    OutlinedTextField(
                        value = liveInputPrompt,
                        onValueChange = { liveInputPrompt = it },
                        label = { Text("Speak or type a real-time prompt for gemini-3.8-live...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("live_voice_prompt_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { liveMicPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("start_live_voice_conversation_button")
                        ) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Talk to Gemini 3.8 Live")
                        }
                        OutlinedButton(
                            onClick = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mic_transcribe_3_5_button")
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = StudioEmeraldSuccess)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Transcribe Mic (3.5)")
                        }
                    }

                    if (lastTranscribed.isNotBlank()) {
                        Text(
                            text = "Last Transcribed (`gemini-3.5-transcribe`): \"$lastTranscribed\"",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioEmeraldSuccess
                        )
                    }

                    liveVoiceTurns.takeLast(3).forEach { turn ->
                        Surface(
                            color = StudioSurfaceElevated,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("You → ${turn.transcriptUser}", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                                Text("${turn.modelUsed}: ${turn.spokenReplyText}", style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                            }
                        }
                    }
                }
            }
        }

        // Section 12 & 37: Voice Creation UI + Regional Accent Library + Voice A/B/C Comparison
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("AI VOICE STUDIO • REGIONAL ACCENTS & A/B/C COMPARISON", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)

                    Text("REGIONAL VOICE & ACCENT FILTER (SECTION 37)", style = MaterialTheme.typography.labelSmall, color = StudioEmeraldSuccess)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        regionalVoices.forEach { reg ->
                            FilterChip(selected = selectedRegion == reg, onClick = { selectedRegion = reg }, label = { Text(reg) })
                        }
                    }

                    Text("VOICE COMPARISON (VOICE A / VOICE B / VOICE C — SECTION 12)", style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        voiceComparisonList.forEach { (vLabel, vSpeed, vPitch) ->
                            val isSelected = selectedComparisonVoice == vLabel
                            Surface(
                                color = if (isSelected) StudioPrimaryContainer else StudioSurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, if (isSelected) StudioPrimaryIndigo else StudioBorderSubtle, RoundedCornerShape(10.dp))
                                    .clickable {
                                        selectedComparisonVoice = vLabel
                                        speed = vSpeed
                                        pitch = vPitch
                                        viewModel.previewVoiceStudio(scriptText, vSpeed, vPitch)
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(vLabel.substringBefore(":"), style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                    Text(vLabel.substringAfter(": "), style = MaterialTheme.typography.labelSmall, color = StudioCyanAccent, maxLines = 1)
                                }
                            }
                        }
                    }

                    Text("VOICE CATEGORY & EMOTION", style = MaterialTheme.typography.labelSmall, color = StudioPrimaryBright)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.forEach { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat) })
                        }
                        emotions.forEach { em ->
                            FilterChip(selected = emotion == em, onClick = { emotion = em }, label = { Text(em.uppercase()) })
                        }
                    }

                    OutlinedTextField(
                        value = scriptText,
                        onValueChange = { scriptText = it },
                        label = { Text("Voice-Over Script (Supports emphasis, pauses & AI Translate)") },
                        minLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("voice_script_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Speed: ${"%.2f".format(speed)}x", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                        Text("Pitch: ${"%.2f".format(pitch)}", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                        Text("Pause: ${pauseMs}ms", style = MaterialTheme.typography.labelMedium, color = StudioCyanAccent)
                    }
                    Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.6f..1.5f)
                    Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.6f..1.4f)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.previewVoiceStudio(scriptText, speed, pitch) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("voice_preview_button")
                        ) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = StudioCyanAccent)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Preview Voice")
                        }
                        Button(
                            onClick = {
                                viewModel.launchModalityGeneration(
                                    jobType = "VOICE",
                                    title = "VO ($selectedRegion • $emotion)",
                                    prompt = "$scriptText [Voice: $selectedComparisonVoice, Region: $selectedRegion, Category: $category, Emotion: $emotion]",
                                    resolutionOrFormat = "48kHz 24-bit WAV • $selectedRegion",
                                    durationSec = 15,
                                    creditCost = 5,
                                    addToTimelineTrack = "VOICE"
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("generate_voice_button")
                        ) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Generate VO (5 CR)")
                        }
                    }
                }
            }
        }

        // Section 9: Consent-Gated Voice Cloning
        item {
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = StudioEmeraldSuccess)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SAFE VOICE CLONING (CONSENT-LOCKED)", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                    }
                    Text(
                        text = "Flow: Upload Voice Sample → Explicit Biometric Consent Confirmation → Acoustic Embedding → Voice Profile.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioTextSecondary
                    )
                    OutlinedTextField(
                        value = cloneProfileName,
                        onValueChange = { cloneProfileName = it },
                        label = { Text("Voice Profile Name (e.g., My Brand Narrator Voice)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { consentConfirmed = !consentConfirmed }
                    ) {
                        Checkbox(
                            checked = consentConfirmed,
                            onCheckedChange = { consentConfirmed = it },
                            modifier = Modifier.testTag("voice_clone_consent_checkbox")
                        )
                        Text(
                            text = "I confirm that I am the speaker in the uploaded voice sample or hold explicit written legal consent to synthesize this voice.",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextPrimary
                        )
                    }
                    Button(
                        onClick = {
                            val name = cloneProfileName.ifBlank { "Custom Studio Voice #${clonedProfiles.size + 1}" }
                            clonedProfiles = clonedProfiles + "$name (Verified Consent)"
                            cloneProfileName = ""
                        },
                        enabled = consentConfirmed,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("create_voice_clone_button")
                    ) {
                        Icon(Icons.Default.GraphicEq, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (consentConfirmed) "Process & Create Verified Voice Profile" else "Confirm Consent Above to Enable Cloning")
                    }

                    clonedProfiles.forEach { profile ->
                        Text("• Active Profile: $profile", style = MaterialTheme.typography.labelMedium, color = StudioEmeraldSuccess)
                    }
                }
            }
        }
    }
}

@Composable
fun MusicAndSfxStudioScreen(
    viewModel: StudioViewModel,
    initialTabIsSfx: Boolean = false
) {
    var activeTab by remember(initialTabIsSfx) { mutableIntStateOf(if (initialTabIsSfx) 1 else 0) }
    var musicMode by remember { mutableStateOf("Short Clip (<=30s • lyria-3-clip-preview)") }
    var genre by remember { mutableStateOf("Cinematic") }
    var mood by remember { mutableStateOf("Dark Anamorphic Tension") }
    var bpm by remember { mutableIntStateOf(118) }
    var durationSec by remember { mutableIntStateOf(30) }
    var musicPrompt by remember { mutableStateOf("Hybrid analog synth bass pulse with orchestral strings building to a cinematic climax") }

    var sfxPrompt by remember { mutableStateOf("Heavy rain hitting a metal roof followed by a futuristic spaceship engine sub-bass whoosh") }

    val genres = listOf("Cinematic", "Pop", "Rock", "Hip Hop", "Electronic", "Ambient", "Jazz", "Classical", "Lo-Fi", "Corporate", "Trailer", "Acoustic")
    val songSections = listOf("Intro (0-4s)", "Verse (4-10s)", "Pre-Chorus (10-15s)", "Chorus (15-22s)", "Bridge (22-26s)", "Outro (26-30s)")
    val stems = listOf("Vocals", "Drums", "Bass", "Melody", "Other")

    val activeLyriaModel = if (durationSec <= 30) "lyria-3-clip-preview" else "lyria-3-pro-preview"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioObsidianBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = StudioSurface,
                contentColor = StudioPrimaryBright
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = { Text("AI Music (Lyria 3 Clip & Pro)") }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = { Text("AI Sound Effects (SFX)") }
                )
            }
        }

        if (activeTab == 0) {
            item { TextToSongCard(viewModel = viewModel) }

            // Section 10, 11, 12, 13: AI Music Studio with lyria-3-clip-preview (<=30s) & lyria-3-pro-preview (>30s)
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("AI MUSIC STUDIO • LYRIA 3 ENGINE", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                            Surface(color = StudioPrimaryContainer, shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = activeLyriaModel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioEmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // AI Recommendation Banner (Section 13: "Recommended for this video")
                        Surface(
                            color = StudioSurfaceElevated,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = StudioCyanAccent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Recommended for this video: 118 BPM Dark Cinematic Hybrid Score ($activeLyriaModel)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = StudioCyanAccent
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                "Short Clip (<=30s • lyria-3-clip-preview)" to 25,
                                "Full-Length Track (60s+ • lyria-3-pro-preview)" to 90,
                                "Background Instrumental" to 30,
                                "Vocal Anthem" to 60
                            ).forEach { (label, dur) ->
                                FilterChip(
                                    selected = musicMode == label,
                                    onClick = {
                                        musicMode = label
                                        durationSec = dur
                                    },
                                    label = { Text(label) }
                                )
                            }
                        }

                        Text("GENRE", style = MaterialTheme.typography.labelSmall, color = StudioEmeraldSuccess)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            genres.forEach { g ->
                                FilterChip(selected = genre == g, onClick = { genre = g }, label = { Text(g) })
                            }
                        }

                        OutlinedTextField(
                            value = musicPrompt,
                            onValueChange = { musicPrompt = it },
                            label = { Text("Music Composition Prompt ($activeLyriaModel)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Tempo: $bpm BPM", style = MaterialTheme.typography.labelMedium, color = StudioCyanAccent)
                            Text("Duration: ${durationSec}s → Model: $activeLyriaModel", style = MaterialTheme.typography.labelMedium, color = StudioEmeraldSuccess)
                        }
                        Slider(
                            value = bpm.toFloat(),
                            onValueChange = { bpm = it.toInt() },
                            valueRange = 70f..160f
                        )
                        Slider(
                            value = durationSec.toFloat(),
                            onValueChange = { durationSec = it.toInt() },
                            valueRange = 10f..120f
                        )

                        // Section 11: Automatic Music Structure
                        Text("ADAPTIVE SONG STRUCTURE", style = MaterialTheme.typography.labelSmall, color = StudioPrimaryBright)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            songSections.forEach { sec ->
                                Surface(
                                    color = StudioSurfaceElevated,
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.border(1.dp, StudioBorderSubtle, RoundedCornerShape(6.dp))
                                ) {
                                    Text(
                                        text = sec,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StudioTextPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.previewSynthesizedAudio(mode = "MUSIC", bpm = bpm, freq = 220.0) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("preview_music_button")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = StudioEmeraldSuccess)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Audition Score")
                            }
                            Button(
                                onClick = {
                                    viewModel.launchModalityGeneration(
                                        jobType = "MUSIC",
                                        title = "$genre ($bpm BPM • $activeLyriaModel)",
                                        prompt = "$musicPrompt | Genre: $genre, Mood: $mood, BPM: $bpm, Model: $activeLyriaModel",
                                        resolutionOrFormat = "48kHz Stereo WAV • $bpm BPM • $activeLyriaModel",
                                        durationSec = durationSec,
                                        creditCost = if (durationSec <= 30) 8 else 14,
                                        addToTimelineTrack = "MUSIC"
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("generate_music_button")
                            ) {
                                Icon(Icons.Default.LibraryMusic, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Generate ($activeLyriaModel)")
                            }
                        }
                    }
                }
            }

            // Section 12: 5-Stem Separation
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("AI STEM SEPARATION (ISOLATE & MOUNT TO TIMELINE)", style = MaterialTheme.typography.titleSmall, color = StudioEmeraldSuccess)
                        Text(
                            text = "Split any Lyria 3 score into 5 independent stems and mount each as a dedicated timeline track.",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary
                        )
                        stems.forEachIndexed { idx, stemName ->
                            Surface(
                                color = StudioSurfaceElevated,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = StudioEmeraldSuccess, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Stem 0${idx + 1}: $stemName", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        TextButton(
                                            onClick = {
                                                viewModel.previewSynthesizedAudio(
                                                    mode = "MUSIC",
                                                    bpm = bpm,
                                                    freq = 140.0 + (idx * 55.0)
                                                )
                                            }
                                        ) {
                                            Text("Solo")
                                        }
                                        Button(
                                            onClick = { viewModel.addSeparatedStemToTimeline(stemName) },
                                            modifier = Modifier.testTag("add_stem_${stemName.lowercase()}_button")
                                        ) {
                                            Text("+ Timeline")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Section 13: AI Sound Effects (Prompt -> SFX + Waveform)
            item {
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("AI SOUND EFFECTS (PROMPT → FOLEY & CINEMATIC SFX)", style = MaterialTheme.typography.titleMedium, color = StudioAmberWarning)

                        val presetSfx = listOf(
                            "heavy rain hitting a metal roof",
                            "futuristic spaceship engine",
                            "cinematic explosion",
                            "footsteps on wooden floor"
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            presetSfx.forEach { preset ->
                                AssistChip(
                                    onClick = { sfxPrompt = preset },
                                    label = { Text(preset) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = sfxPrompt,
                            onValueChange = { sfxPrompt = it },
                            label = { Text("Describe Sound Effect") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sfx_prompt_input")
                        )

                        // Interactive Waveform Display
                        Surface(
                            color = StudioObsidianBg,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(84.dp)
                                .border(1.dp, StudioBorderSubtle, RoundedCornerShape(10.dp))
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp)) {
                                val barCount = 48
                                val step = size.width / barCount
                                val barWidth = (step * 0.6f).coerceAtLeast(3f)
                                for (i in 0 until barCount) {
                                    val norm = (0.25f + 0.72f * kotlin.math.abs(sin(i * 0.42f + sfxPrompt.length * 0.1f))).coerceIn(0.15f, 1f)
                                    val barHeight = size.height * norm
                                    val top = (size.height - barHeight) / 2f
                                    drawRoundRect(
                                        color = if (i % 4 == 0) StudioAmberWarning else StudioCyanAccent,
                                        topLeft = Offset(i * step, top),
                                        size = Size(barWidth, barHeight),
                                        cornerRadius = CornerRadius(3f, 3f)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.previewSynthesizedAudio(mode = "SFX", bpm = 120, freq = 160.0) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("preview_sfx_button")
                            ) {
                                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = StudioAmberWarning)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Preview SFX")
                            }
                            Button(
                                onClick = {
                                    viewModel.launchModalityGeneration(
                                        jobType = "SFX",
                                        title = "SFX: ${sfxPrompt.take(20)}",
                                        prompt = sfxPrompt,
                                        resolutionOrFormat = "48kHz WAV • Foley Master",
                                        durationSec = 6,
                                        creditCost = 3,
                                        addToTimelineTrack = "SFX"
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("generate_sfx_button")
                            ) {
                                Icon(Icons.Default.GraphicEq, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Generate & Add to Timeline (3 CR)")
                            }
                        }
                    }
                }
            }
        }
    }
}
