package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String,
    val concept: String = "",
    val targetAudience: String = "",
    val hook: String = "",
    val script: String = "",
    val cta: String = "",
    val aspectRatio: String = "16:9",
    val resolution: String = "1080p",
    val fps: Int = 24,
    val totalDurationSec: Int = 30,
    val styleLockEnabled: Boolean = false,
    val styleReferenceName: String = "Anamorphic Cyber-Noir",
    val styleColorPalette: String = "Obsidian, Electric Indigo, Rain Cyan",
    val styleLighting: String = "Neon Cinematic High-Contrast",
    val styleCamera: String = "35mm Anamorphic Low-Angle Tracking",
    val styleMood: String = "Luxury, Futuristic, Suspenseful",
    val brandKitId: Long? = 1L,
    val autosaveStatus: String = "Saved",
    val currentVersion: Int = 1,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val isTrashed: Boolean = false,
    val shareMode: String = "Private", // Private, Public, Password
    val sharePassword: String = "",
    val workspaceRole: String = "Owner",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "scenes")
data class SceneEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val sceneNumber: Int,
    val durationSec: Int = 5,
    val visualDescription: String,
    val imagePrompt: String,
    val videoPrompt: String,
    val cameraDirection: String = "Tracking",
    val lens: String = "35mm",
    val lighting: String = "Cinematic",
    val voiceScript: String = "",
    val musicPrompt: String = "Dark cinematic ambient",
    val sfxPrompt: String = "Subtle atmospheric whoosh",
    val subtitleText: String = "",
    val variantCount: Int = 3,
    val selectedVariant: Int = 1,
    val aiAlternativeVisual: String = "",
    val status: String = "READY" // READY, GENERATING, RENDERED
)

@Entity(tableName = "timeline_clips")
data class TimelineClipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val trackType: String, // VIDEO, IMAGE, VOICE, MUSIC, SFX, SUBTITLE
    val label: String,
    val startSec: Float,
    val durationSec: Float,
    val volume: Float = 1.0f,
    val pan: Float = 0.0f,
    val isMuted: Boolean = false,
    val isSolo: Boolean = false,
    val fadeInSec: Float = 0.2f,
    val fadeOutSec: Float = 0.3f,
    val keyframeData: String = "Pos(0,0) Scale(1.0) Opacity(100%)",
    val stemType: String = "Full Mix", // Full Mix, Vocals, Drums, Bass, Melody, Other
    val colorHex: String = "#6366F1"
)

@Entity(tableName = "assets")
data class AssetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long = 1L,
    val name: String,
    val type: String, // IMAGE, VIDEO, AUDIO, VOICE, MUSIC, SFX, SUBTITLE
    val folder: String = "Production Master",
    val durationSec: Int = 5,
    val formatInfo: String = "1080p MP4 • 24fps",
    val promptUsed: String = "",
    val audioFreqHz: Int = 440,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "generation_jobs")
data class GenerationJobEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long = 1L,
    val title: String,
    val prompt: String,
    val enhancedPrompt: String = "",
    val jobType: String, // DIRECTOR_PLAN, COMPLETE_VIDEO, VIDEO, IMAGE, VOICE, MUSIC, SFX, SUBTITLE, AUTO_EDIT, VIRAL_OPTIMIZE, EXPORT
    val modelTier: String = "Cinematic", // Fast, Balanced, Quality, Cinematic
    val modelName: String = "gemini-3.1-pro-preview",
    val resolution: String = "1080p",
    val durationSec: Int = 15,
    val creditCost: Int = 12,
    val status: String = "COMPLETED", // QUEUED, ANALYZING, PLANNING, GENERATING, MIXING, QUALITY_CHECK, COMPLETED, FAILED
    val progressPercent: Int = 100,
    val stageMessage: String = "Completed",
    val outputSummary: String = "",
    val qualityReport: String = "QC Passed: 0 black frames • -14 LUFS normalized • Subtitle sync 99.8%",
    val variantsGenerated: Int = 3,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "character_profiles")
data class CharacterProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val age: String,
    val appearance: String,
    val clothes: String,
    val personality: String,
    val avatarColorHex: String = "#6366F1",
    val isConsistentLockActive: Boolean = true
)

@Entity(tableName = "brand_kits")
data class BrandKitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val logoText: String,
    val primaryColorHex: String,
    val secondaryColorHex: String,
    val fontFamilyName: String,
    val watermarkPosition: String = "Bottom-Right",
    val watermarkOpacity: Float = 0.75f,
    val watermarkSize: String = "Medium",
    val introStyle: String = "Minimal Sonic Logo (1.5s)",
    val outroStyle: String = "CTA Product Card + URL (3.0s)",
    val isActive: Boolean = true
)

@Entity(tableName = "prompt_templates")
data class PromptTemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String, // Ads, TikTok, Reels, YouTube, Podcast, Corporate, Real Estate, Product, Education, Documentary, Music Video
    val promptText: String,
    val variablesCsv: String = "{product},{location},{mood}",
    val isMarketplaceTemplate: Boolean = true,
    val aspectRatio: String = "16:9",
    val durationSec: Int = 30,
    val previewStyle: String = "Cinematic Anamorphic",
    val isFavorite: Boolean = false
)

@Entity(tableName = "project_versions")
data class ProjectVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val versionNumber: Int,
    val label: String,
    val summary: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "credit_transactions")
data class CreditTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val idempotencyKey: String,
    val description: String,
    val deltaCredits: Int,
    val balanceAfter: Int,
    val planName: String = "Pro Studio",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "studio_notifications")
data class StudioNotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val category: String, // GENERATION, EXPORT, BILLING, QUALITY
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
