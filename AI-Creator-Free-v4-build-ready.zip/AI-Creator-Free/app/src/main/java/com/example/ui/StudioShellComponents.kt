package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.GenerationJobEntity
import com.example.data.ProjectEntity
import com.example.data.StudioNotificationEntity
import com.example.i18n.LocalStudioLocalizer
import com.example.i18n.StudioExperienceMode
import com.example.i18n.StudioLanguage
import com.example.ui.theme.*
import com.example.viewmodel.PendingCreditAction
import com.example.viewmodel.StudioDestination

fun destinationIcon(dest: StudioDestination): ImageVector = when (dest) {
    StudioDestination.HOME -> Icons.Default.Dashboard
    StudioDestination.AI_DIRECTOR -> Icons.Default.AutoAwesome
    StudioDestination.VIDEO -> Icons.Default.Videocam
    StudioDestination.IMAGE -> Icons.Default.Image
    StudioDestination.VOICE -> Icons.Default.RecordVoiceOver
    StudioDestination.MUSIC -> Icons.Default.LibraryMusic
    StudioDestination.SOUND_EFFECTS -> Icons.Default.GraphicEq
    StudioDestination.STUDIO -> Icons.Default.MovieCreation
    StudioDestination.PROJECTS -> Icons.Default.FolderSpecial
    StudioDestination.ASSETS -> Icons.Default.PermMedia
    StudioDestination.TEMPLATES -> Icons.Default.ViewQuilt
    StudioDestination.BRAND_KIT -> Icons.Default.Palette
    StudioDestination.AI_ASSISTANT -> Icons.AutoMirrored.Filled.Chat
    StudioDestination.HISTORY -> Icons.Default.History
    StudioDestination.EXPORTS -> Icons.Default.IosShare
    StudioDestination.BILLING -> Icons.Default.AccountBalanceWallet
    StudioDestination.SETTINGS -> Icons.Default.AdminPanelSettings
}

@Composable
fun StudioTopHeaderBar(
    activeProject: ProjectEntity?,
    credits: Int,
    planName: String,
    activeJobsCount: Int,
    unreadNotificationsCount: Int,
    selectedLanguage: StudioLanguage = StudioLanguage.EN,
    experienceMode: StudioExperienceMode = StudioExperienceMode.PRO,
    onSelectLanguage: (StudioLanguage) -> Unit = {},
    onToggleExperienceMode: () -> Unit = {},
    onUndo: () -> Unit = {},
    onRedo: () -> Unit = {},
    onOpenDrawer: () -> Unit,
    onOpenCommandPalette: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenArchitectureAudit: () -> Unit,
    onNavigateToBilling: () -> Unit,
    onNavigateToExport: () -> Unit = {},
    showMenuButton: Boolean
) {
    val i18n = LocalStudioLocalizer.current
    var showLanguageMenu by remember { mutableStateOf(false) }

    Surface(
        color = StudioSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = StudioBorderSubtle)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                if (showMenuButton) {
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("open_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Open Studio Navigation",
                            tint = StudioTextPrimary
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(StudioPrimaryIndigo),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
                if (!showMenuButton) {
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f, fill = false)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = activeProject?.title ?: "AI Creative Studio",
                            style = MaterialTheme.typography.titleMedium,
                            color = StudioTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 170.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        // Autosave badge (Section 6: Saving... / Saved / Unsaved changes)
                        val rawStatus = activeProject?.autosaveStatus ?: "Saved"
                        val localizedStatus = when {
                            rawStatus.startsWith("Saving") -> i18n.t("common.saving")
                            rawStatus.startsWith("Unsaved") -> i18n.t("common.unsaved")
                            else -> i18n.t("common.saved")
                        }
                        Surface(
                            color = StudioSurfaceHigh,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = localizedStatus,
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioEmeraldSuccess,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "${activeProject?.aspectRatio ?: "16:9"} • ${activeProject?.resolution ?: "4K"} • ${selectedLanguage.nativeName}${if (selectedLanguage.isRtl) " (RTL)" else ""}",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Undo / Redo (Section 6 Top Bar)
                if (!showMenuButton) {
                    IconButton(
                        onClick = onUndo,
                        modifier = Modifier.size(34.dp).testTag("topbar_undo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = StudioTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onRedo,
                        modifier = Modifier.size(34.dp).testTag("topbar_redo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = StudioTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Simple / Pro Mode Pill (Section 48)
                Surface(
                    color = if (experienceMode == StudioExperienceMode.PRO) StudioPrimaryContainer else StudioSurfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(8.dp))
                        .clickable { onToggleExperienceMode() }
                        .testTag("toggle_pro_mode_button")
                ) {
                    Text(
                        text = if (experienceMode == StudioExperienceMode.BEGINNER) "SIMPLE" else "PRO",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioCyanAccent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }

                // Global 19-Language Selector (Sections 18–21)
                Box {
                    Surface(
                        color = StudioSurfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .border(1.dp, StudioBorderSubtle, RoundedCornerShape(8.dp))
                            .clickable { showLanguageMenu = true }
                            .testTag("language_selector_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language Selector",
                                tint = StudioCyanAccent,
                                modifier = Modifier.size(15.dp)
                            )
                            if (!showMenuButton) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = selectedLanguage.code.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioTextPrimary
                                )
                            }
                        }
                    }

                    DropdownMenu(
                        expanded = showLanguageMenu,
                        onDismissRequest = { showLanguageMenu = false },
                        modifier = Modifier
                            .background(StudioSurfaceElevated)
                            .heightIn(max = 360.dp)
                    ) {
                        StudioLanguage.entries.forEach { lang ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${lang.nativeName} (${lang.englishName})",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (lang == selectedLanguage) StudioCyanAccent else StudioTextPrimary
                                        )
                                        if (lang.isRtl) {
                                            Text(
                                                text = "RTL",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = StudioAmberWarning
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    onSelectLanguage(lang)
                                    showLanguageMenu = false
                                }
                            )
                        }
                    }
                }

                // Command Palette Trigger (Ctrl+K)
                Surface(
                    color = StudioSurfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(8.dp))
                        .clickable { onOpenCommandPalette() }
                        .testTag("command_palette_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Command Palette",
                            tint = StudioTextSecondary,
                            modifier = Modifier.size(15.dp)
                        )
                        if (!showMenuButton) {
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "⌘K",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioPrimaryBright
                            )
                        }
                    }
                }

                // Export Quick Trigger (Section 6 Top Bar)
                if (!showMenuButton) {
                    Surface(
                        color = StudioSurfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .border(1.dp, StudioBorderSubtle, RoundedCornerShape(8.dp))
                            .clickable { onNavigateToExport() }
                            .testTag("topbar_export_button")
                    ) {
                        Text(
                            text = i18n.t("common.export"),
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioEmeraldSuccess,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }

                // Credits Pill (Section 6 & 29)
                Surface(
                    color = StudioPrimaryContainer,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .border(1.dp, StudioPrimaryIndigo.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                        .clickable { onNavigateToBilling() }
                        .testTag("credits_badge_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = StudioAmberWarning,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "$credits CR",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioTextPrimary,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                // Notifications Icon
                BadgedBox(
                    badge = {
                        if (unreadNotificationsCount > 0 || activeJobsCount > 0) {
                            Badge(containerColor = StudioRoseDanger) {
                                Text("${unreadNotificationsCount + activeJobsCount}")
                            }
                        }
                    }
                ) {
                    IconButton(
                        onClick = onOpenNotifications,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("notifications_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications & Job Queue",
                            tint = StudioTextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CollapsibleStudioSidebar(
    currentDestination: StudioDestination,
    isCollapsed: Boolean,
    onToggleCollapse: () -> Unit,
    onSelectDestination: (StudioDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val i18n = LocalStudioLocalizer.current
    val width = if (isCollapsed) 68.dp else 224.dp
    Surface(
        color = StudioSurface,
        modifier = modifier
            .width(width)
            .fillMaxHeight()
            .border(1.dp, StudioBorderSubtle)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = if (isCollapsed) Arrangement.Center else Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isCollapsed) {
                    Text(
                        text = "GLOBAL STUDIO V2",
                        style = MaterialTheme.typography.labelMedium,
                        color = StudioTextSecondary
                    )
                }
                IconButton(
                    onClick = onToggleCollapse,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("toggle_sidebar_collapse")
                ) {
                    Icon(
                        imageVector = if (isCollapsed) Icons.Default.ChevronRight else Icons.Default.ChevronLeft,
                        contentDescription = "Toggle Sidebar",
                        tint = StudioTextSecondary
                    )
                }
            }

            HorizontalDivider(color = StudioBorderSubtle)

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                val grouped = StudioDestination.entries.groupBy { it.group }
                grouped.forEach { (groupName, destinations) ->
                    if (!isCollapsed) {
                        item(key = "header_$groupName") {
                            Text(
                                text = groupName,
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextMuted,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                    }
                    items(destinations, key = { it.name }) { dest ->
                        val selected = dest == currentDestination
                        val bgColor = if (selected) StudioPrimaryContainer else Color.Transparent
                        val contentColor = if (selected) StudioPrimaryBright else StudioTextSecondary
                        val localizedLabel = i18n.t(dest.i18nKey)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(bgColor)
                                .clickable { onSelectDestination(dest) }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .testTag("nav_${dest.name.lowercase()}"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = if (isCollapsed) Arrangement.Center else Arrangement.Start
                        ) {
                            Icon(
                                imageVector = destinationIcon(dest),
                                contentDescription = localizedLabel,
                                tint = contentColor,
                                modifier = Modifier.size(20.dp)
                            )
                            if (!isCollapsed) {
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = localizedLabel,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (selected) StudioTextPrimary else StudioTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/** "Ses & Canlı" -> "Ses", "Video (Veo 3.1)" -> "Video", "AI Yönetmen" -> "AI Yönetmen". */
internal fun shortNavLabel(raw: String): String {
    val base = raw.substringBefore(" (").substringBefore(" &").trim()
    val words = base.split(" ").filter { it.isNotBlank() }
    return when {
        words.size <= 1 -> base
        words[0].length <= 3 -> words.take(2).joinToString(" ")
        else -> words[0]
    }
}

@Composable
fun MobileStudioBottomBar(
    currentDestination: StudioDestination,
    onSelectDestination: (StudioDestination) -> Unit,
    onOpenMoreDrawer: () -> Unit
) {
    val i18n = LocalStudioLocalizer.current
    val primaryTabs = listOf(
        StudioDestination.HOME,
        StudioDestination.AI_DIRECTOR,
        StudioDestination.STUDIO,
        StudioDestination.VIDEO,
        StudioDestination.VOICE
    )
    NavigationBar(
        containerColor = StudioSurface,
        tonalElevation = 0.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioBorderSubtle)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        primaryTabs.forEach { dest ->
            val selected = currentDestination == dest
            val labelText = shortNavLabel(i18n.t(dest.i18nKey))
            NavigationBarItem(
                selected = selected,
                onClick = { onSelectDestination(dest) },
                icon = {
                    Icon(
                        imageVector = destinationIcon(dest),
                        contentDescription = labelText
                    )
                },
                label = {
                    Text(
                        text = labelText,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = StudioPrimaryBright,
                    selectedTextColor = StudioTextPrimary,
                    indicatorColor = StudioPrimaryContainer,
                    unselectedIconColor = StudioTextSecondary,
                    unselectedTextColor = StudioTextSecondary
                ),
                modifier = Modifier.testTag("bottom_nav_${dest.name.lowercase()}")
            )
        }
        NavigationBarItem(
            selected = currentDestination !in primaryTabs,
            onClick = onOpenMoreDrawer,
            icon = {
                Icon(
                    imageVector = Icons.Default.Apps,
                    contentDescription = "All 17 Studio Modules"
                )
            },
            label = {
                Text(
                    text = "More",
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    softWrap = false
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = StudioCyanAccent,
                selectedTextColor = StudioTextPrimary,
                indicatorColor = StudioPrimaryContainer,
                unselectedIconColor = StudioTextSecondary,
                unselectedTextColor = StudioTextSecondary
            ),
            modifier = Modifier.testTag("bottom_nav_more_modules")
        )
    }
}

@Composable
fun CommandPaletteDialog(
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onSelectDestination: (StudioDestination) -> Unit,
    onQuickAction: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val i18n = LocalStudioLocalizer.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurfaceElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Terminal, contentDescription = null, tint = StudioPrimaryBright)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Global Command Palette (Ctrl/Cmd + K)", style = MaterialTheme.typography.titleMedium)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("Search localized commands, studios, projects, or shortcuts...") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("command_palette_input")
                )
                Spacer(modifier = Modifier.height(12.dp))
                val commands = listOf(
                    Triple(i18n.t("cmd.createVideo") + " (Veo 3.1 • 16-Stage Pipeline)", "Shift+Enter", "COMPLETE_VIDEO"),
                    Triple(i18n.t("cmd.createVoice") + " (Gemini TTS & 3.8 Live)", "⌘L", "VOICE"),
                    Triple(i18n.t("cmd.createMusic") + " (Lyria 3 Clip & Pro)", "⌘M", "MUSIC"),
                    Triple(i18n.t("cmd.exportProject") + " (4K Master / SRT)", "⌘Shift+E", "EXPORT"),
                    Triple("Launch AI Director & Creative Brief", "⌘D", "DIRECTOR"),
                    Triple("Auto-Edit Active Timeline", "⌘E", "AUTO_EDIT"),
                    Triple("Make It Viral (Analyze & Optimize Hook)", "⌘V", "VIRAL")
                ).filter {
                    searchQuery.isBlank() || it.first.contains(searchQuery, ignoreCase = true)
                }

                LazyColumn(modifier = Modifier.heightIn(max = 260.dp)) {
                    items(commands) { (title, shortcut, code) ->
                        Surface(
                            color = StudioSurface,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable {
                                    onQuickAction(code)
                                    onDismiss()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = StudioTextPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = shortcut,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioCyanAccent
                                )
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "JUMP TO STUDIO MODULE",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioTextMuted
                        )
                    }
                    val matchingDests = StudioDestination.entries.filter {
                        val locName = i18n.t(it.i18nKey)
                        searchQuery.isBlank() || it.label.contains(searchQuery, ignoreCase = true) || locName.contains(searchQuery, ignoreCase = true)
                    }
                    items(matchingDests) { dest ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectDestination(dest) }
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(destinationIcon(dest), contentDescription = null, tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(i18n.t(dest.i18nKey), style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(i18n.t("common.cancel"))
            }
        }
    )
}

@Composable
fun CreditEstimationConfirmationDialog(
    pendingAction: PendingCreditAction,
    currentBalance: Int,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val i18n = LocalStudioLocalizer.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurfaceElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Bolt, contentDescription = null, tint = StudioAmberWarning)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Credit Cost Estimation", style = MaterialTheme.typography.titleMedium)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = pendingAction.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = StudioTextPrimary
                )
                Text(
                    text = pendingAction.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = StudioTextSecondary
                )
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, StudioBorderSubtle, RoundedCornerShape(10.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Estimated Cost:", style = MaterialTheme.typography.bodyMedium, color = StudioTextSecondary)
                            Text("${pendingAction.estimatedCredits} credits", style = MaterialTheme.typography.labelLarge, color = StudioAmberWarning)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Balance After Generation:", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                            Text("${(currentBalance - pendingAction.estimatedCredits).coerceAtLeast(0)} credits", style = MaterialTheme.typography.labelMedium, color = StudioEmeraldSuccess)
                        }
                    }
                }
                Text(
                    text = "Transaction-safe idempotency guarantees you are never double-charged.",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextMuted
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo),
                modifier = Modifier.testTag("confirm_credit_generation_button")
            ) {
                Text("${i18n.t("common.generate")} (${pendingAction.estimatedCredits} CR)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(i18n.t("common.cancel"))
            }
        }
    )
}

@Composable
fun NotificationsAndQueueDialog(
    jobs: List<GenerationJobEntity>,
    notifications: List<StudioNotificationEntity>,
    onRetryJob: (GenerationJobEntity) -> Unit,
    onMarkAllRead: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurfaceElevated,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Global Queue & Pipeline Stages", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onMarkAllRead) {
                    Text("Mark All Read", style = MaterialTheme.typography.labelSmall)
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 360.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(
                        "LIVE PIPELINE: ANALYZING → PLANNING → WRITING → GENERATING → COMPOSING → EDITING → MIXING → RENDERING → QC → COMPLETE",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioCyanAccent
                    )
                }
                items(jobs.take(5), key = { "job_${it.id}" }) { job ->
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, StudioBorderSubtle, RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(job.title, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                Text("${job.progressPercent}%", style = MaterialTheme.typography.labelMedium, color = StudioEmeraldSuccess)
                            }
                            Text(job.stageMessage, style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { job.progressPercent / 100f },
                                modifier = Modifier.fillMaxWidth(),
                                color = if (job.status == "COMPLETED") StudioEmeraldSuccess else StudioPrimaryIndigo,
                                trackColor = StudioSurfaceHigh
                            )
                            if (job.status == "FAILED") {
                                TextButton(onClick = { onRetryJob(job) }) {
                                    Text("Retry Job")
                                }
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("NOTIFICATIONS", style = MaterialTheme.typography.labelSmall, color = StudioPrimaryBright)
                }
                items(notifications, key = { "notif_${it.id}" }) { notif ->
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(notif.title, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                            Text(notif.message, style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}

@Composable
fun ArchitectureAuditModal(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurfaceElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Architecture, contentDescription = null, tint = StudioCyanAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Global Architecture, AI Models & Multilingual Spec", style = MaterialTheme.typography.titleMedium)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 400.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val auditSections = listOf(
                    "1. Multimodal AI Engine" to "Integrated Veo 3.1 (`veo-3.1-generate-preview` 16:9 & 9:16 Text/Image-to-Video), Lyria 3 (`lyria-3-clip-preview` & `lyria-3-pro-preview`), Image Creation/Editing (`gemini-3.1-flash-image-preview`), Mic Transcription (`gemini-3.5-transcribe`), Live Voice (`gemini-3.8-live`), and Google Search Grounding (`gemini-3.5-flash` + `googleSearch`).",
                    "2. Global Localization & True RTL (19 Languages)" to "Supports EN, TR, DE, FR, ES, IT, PT, NL, AR (RTL), HE (RTL), HI, ID, JA, KO, ZH-CN, ZH-TW, RU, UK, PL with dynamic LayoutDirection switching, English fallback, Translation Memory & Glossary.",
                    "3. Hybrid Cloud + Local Persistence" to "Room SQLite (11 normalized tables + @Transaction credit idempotency) paired with Firebase Auth (Google Sign-In via CredentialManager) & Cloud Firestore project/credit replication.",
                    "4. Multi-Currency & International Pricing" to "Locale-aware formatting across USD, EUR, GBP, CAD, AUD, JPY, CHF with Monthly/Yearly plans (Free, Creator, Pro, Studio, Enterprise).",
                    "5. Security & APK Portability" to "API keys injected via Secrets Gradle Plugin (.env.example -> BuildConfig.GEMINI_API_KEY) and safe debug keystore check so exported ZIP builds cleanly anywhere."
                )
                items(auditSections) { (heading, detail) ->
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, StudioBorderSubtle, RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(heading, style = MaterialTheme.typography.titleSmall, color = StudioCyanAccent)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(detail, style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = StudioPrimaryIndigo)
            ) {
                Text("Close Report")
            }
        }
    )
}
