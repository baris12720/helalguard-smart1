package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.i18n.LocalStudioLocalizer
import com.example.i18n.StudioExperienceMode
import com.example.i18n.StudioLocalizer
import com.example.ui.*
import com.example.ui.theme.*
import com.example.viewmodel.StudioDestination
import com.example.viewmodel.StudioViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        com.example.ai.ApiKeyStore.init(applicationContext)
        setContent {
            val studioViewModel: StudioViewModel = viewModel()
            val isDarkMode by studioViewModel.isDarkMode.collectAsStateWithLifecycle()
            MyApplicationTheme(darkTheme = isDarkMode) {
                AiCreativeStudioApp(studioViewModel = studioViewModel)
            }
        }
    }
}

@Composable
fun AiCreativeStudioApp(
    studioViewModel: StudioViewModel = viewModel()
) {
    val currentDestination by studioViewModel.currentDestination.collectAsStateWithLifecycle()
    val isSidebarCollapsed by studioViewModel.isSidebarCollapsed.collectAsStateWithLifecycle()
    val isCommandPaletteOpen by studioViewModel.isCommandPaletteOpen.collectAsStateWithLifecycle()
    val isNotificationSheetOpen by studioViewModel.isNotificationSheetOpen.collectAsStateWithLifecycle()
    val isArchitectureAuditOpen by studioViewModel.isArchitectureAuditOpen.collectAsStateWithLifecycle()
    val globalSearchQuery by studioViewModel.globalSearchQuery.collectAsStateWithLifecycle()
    val pendingCreditAction by studioViewModel.pendingCreditAction.collectAsStateWithLifecycle()
    val statusBannerMessage by studioViewModel.statusBannerMessage.collectAsStateWithLifecycle()

    val selectedLanguage by studioViewModel.selectedLanguage.collectAsStateWithLifecycle()
    val experienceMode by studioViewModel.experienceMode.collectAsStateWithLifecycle()

    val activeProjectId by studioViewModel.activeProjectId.collectAsStateWithLifecycle()
    val activeProjects by studioViewModel.activeProjects.collectAsStateWithLifecycle()
    val trashedProjects by studioViewModel.trashedProjects.collectAsStateWithLifecycle()
    val activeScenes by studioViewModel.activeScenes.collectAsStateWithLifecycle()
    val activeClips by studioViewModel.activeClips.collectAsStateWithLifecycle()
    val projectVersions by studioViewModel.projectVersions.collectAsStateWithLifecycle()
    val allAssets by studioViewModel.allAssets.collectAsStateWithLifecycle()
    val allJobs by studioViewModel.allJobs.collectAsStateWithLifecycle()
    val characters by studioViewModel.characters.collectAsStateWithLifecycle()
    val brandKits by studioViewModel.brandKits.collectAsStateWithLifecycle()
    val templates by studioViewModel.templates.collectAsStateWithLifecycle()
    val creditTransactions by studioViewModel.creditTransactions.collectAsStateWithLifecycle()
    val notifications by studioViewModel.notifications.collectAsStateWithLifecycle()
    val currentCredits by studioViewModel.currentCredits.collectAsStateWithLifecycle()
    val currentPlanName by studioViewModel.currentPlanName.collectAsStateWithLifecycle()

    val activeProject = activeProjects.find { it.id == activeProjectId } ?: activeProjects.firstOrNull()
    val activeJobsCount = allJobs.count { it.status !in listOf("COMPLETED", "FAILED") }
    val unreadNotifsCount = notifications.count { !it.isRead }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    val localizer = remember(selectedLanguage) {
        StudioLocalizer(selectedLanguage)
    }

    // Handle system Back button across all secondary screens
    BackHandler(enabled = currentDestination != StudioDestination.HOME) {
        studioViewModel.navigateBack()
    }

    CompositionLocalProvider(
        LocalStudioLocalizer provides localizer,
        LocalLayoutDirection provides selectedLanguage.layoutDirection
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown) {
                        when {
                            (event.isCtrlPressed || event.isMetaPressed) && event.key == Key.K -> {
                                studioViewModel.setCommandPaletteOpen(true)
                                true
                            }
                            (event.isCtrlPressed || event.isMetaPressed) && event.key == Key.Z -> {
                                studioViewModel.undoTimelineAction()
                                true
                            }
                            (event.isCtrlPressed || event.isMetaPressed) && event.key == Key.Y -> {
                                studioViewModel.redoTimelineAction()
                                true
                            }
                            else -> false
                        }
                    } else {
                        false
                    }
                }
        ) {
            val isWideScreen = maxWidth >= 700.dp

            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = !isWideScreen,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = StudioSurface,
                        modifier = Modifier.width(260.dp)
                    ) {
                        CollapsibleStudioSidebar(
                            currentDestination = currentDestination,
                            isCollapsed = false,
                            onToggleCollapse = {
                                coroutineScope.launch { drawerState.close() }
                            },
                            onSelectDestination = { dest ->
                                studioViewModel.navigateTo(dest)
                                coroutineScope.launch { drawerState.close() }
                            },
                            modifier = Modifier.fillMaxHeight()
                        )
                    }
                }
            ) {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    topBar = {
                        Column {
                            StudioTopHeaderBar(
                                activeProject = activeProject,
                                credits = currentCredits,
                                planName = currentPlanName,
                                activeJobsCount = activeJobsCount,
                                unreadNotificationsCount = unreadNotifsCount,
                                selectedLanguage = selectedLanguage,
                                experienceMode = experienceMode,
                                onSelectLanguage = { studioViewModel.setStudioLanguage(it) },
                                onToggleExperienceMode = {
                                    val nextMode = when (experienceMode) {
                                        StudioExperienceMode.BEGINNER -> StudioExperienceMode.CREATOR
                                        StudioExperienceMode.CREATOR -> StudioExperienceMode.PRO
                                        StudioExperienceMode.PRO -> StudioExperienceMode.BEGINNER
                                    }
                                    studioViewModel.setExperienceMode(nextMode)
                                },
                                onUndo = { studioViewModel.undoTimelineAction() },
                                onRedo = { studioViewModel.redoTimelineAction() },
                                onOpenDrawer = {
                                    coroutineScope.launch { drawerState.open() }
                                },
                                onOpenCommandPalette = {
                                    studioViewModel.setCommandPaletteOpen(true)
                                },
                                onOpenNotifications = {
                                    studioViewModel.setNotificationSheetOpen(true)
                                },
                                onOpenArchitectureAudit = {
                                    studioViewModel.setArchitectureAuditOpen(true)
                                },
                                onNavigateToBilling = {
                                    studioViewModel.navigateTo(StudioDestination.BILLING)
                                },
                                onNavigateToExport = {
                                    studioViewModel.navigateTo(StudioDestination.EXPORTS)
                                },
                                showMenuButton = !isWideScreen
                            )

                            // Non-intrusive Status / Autosave / Safety Toast Banner
                            AnimatedVisibility(visible = statusBannerMessage != null) {
                                statusBannerMessage?.let { msg ->
                                    Surface(
                                        color = StudioPrimaryContainer,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, StudioPrimaryIndigo)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp, vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Info,
                                                    contentDescription = null,
                                                    tint = StudioCyanAccent,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = msg,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = StudioTextPrimary
                                                )
                                            }
                                            IconButton(
                                                onClick = { studioViewModel.dismissStatusBanner() },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "Dismiss",
                                                    tint = StudioTextSecondary,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    bottomBar = {
                        if (!isWideScreen) {
                            MobileStudioBottomBar(
                                currentDestination = currentDestination,
                                onSelectDestination = { studioViewModel.navigateTo(it) },
                                onOpenMoreDrawer = {
                                    coroutineScope.launch { drawerState.open() }
                                }
                            )
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (isWideScreen) {
                            CollapsibleStudioSidebar(
                                currentDestination = currentDestination,
                                isCollapsed = isSidebarCollapsed,
                                onToggleCollapse = { studioViewModel.toggleSidebarCollapsed() },
                                onSelectDestination = { studioViewModel.navigateTo(it) }
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        ) {
                            when (currentDestination) {
                                StudioDestination.HOME -> HomeDashboardScreen(
                                    viewModel = studioViewModel,
                                    projects = activeProjects,
                                    jobs = allJobs,
                                    templates = templates,
                                    assets = allAssets,
                                    credits = currentCredits,
                                    planName = currentPlanName
                                )
                                StudioDestination.AI_DIRECTOR -> AiDirectorScreen(
                                    viewModel = studioViewModel,
                                    activeProject = activeProject,
                                    scenes = activeScenes,
                                    characters = characters
                                )
                                StudioDestination.VIDEO -> VideoStudioScreen(
                                    viewModel = studioViewModel
                                )
                                StudioDestination.IMAGE -> ImageAndCharacterStudioScreen(
                                    viewModel = studioViewModel,
                                    characters = characters
                                )
                                StudioDestination.VOICE -> VoiceStudioScreen(
                                    viewModel = studioViewModel
                                )
                                StudioDestination.MUSIC -> MusicAndSfxStudioScreen(
                                    viewModel = studioViewModel,
                                    initialTabIsSfx = false
                                )
                                StudioDestination.SOUND_EFFECTS -> MusicAndSfxStudioScreen(
                                    viewModel = studioViewModel,
                                    initialTabIsSfx = true
                                )
                                StudioDestination.STUDIO -> TimelineStudioScreen(
                                    viewModel = studioViewModel,
                                    activeProject = activeProject,
                                    scenes = activeScenes,
                                    clips = activeClips,
                                    versions = projectVersions
                                )
                                StudioDestination.PROJECTS -> ProjectsWorkspaceScreen(
                                    viewModel = studioViewModel,
                                    activeProjects = activeProjects,
                                    trashedProjects = trashedProjects
                                )
                                StudioDestination.ASSETS -> AssetLibraryScreen(
                                    viewModel = studioViewModel,
                                    assets = allAssets
                                )
                                StudioDestination.TEMPLATES -> TemplatesAndPromptsScreen(
                                    viewModel = studioViewModel,
                                    templates = templates
                                )
                                StudioDestination.BRAND_KIT -> BrandKitScreen(
                                    viewModel = studioViewModel,
                                    brandKits = brandKits
                                )
                                StudioDestination.AI_ASSISTANT -> AiAssistantChatScreen(
                                    viewModel = studioViewModel
                                )
                                StudioDestination.HISTORY -> GenerationHistoryAndExportScreen(
                                    viewModel = studioViewModel,
                                    jobs = allJobs,
                                    initialIsExport = false
                                )
                                StudioDestination.EXPORTS -> GenerationHistoryAndExportScreen(
                                    viewModel = studioViewModel,
                                    jobs = allJobs,
                                    initialIsExport = true
                                )
                                StudioDestination.BILLING -> BillingAndAdminScreen(
                                    viewModel = studioViewModel,
                                    credits = currentCredits,
                                    planName = currentPlanName,
                                    transactions = creditTransactions,
                                    jobs = allJobs,
                                    initialIsSettingsAdmin = false
                                )
                                StudioDestination.SETTINGS -> BillingAndAdminScreen(
                                    viewModel = studioViewModel,
                                    credits = currentCredits,
                                    planName = currentPlanName,
                                    transactions = creditTransactions,
                                    jobs = allJobs,
                                    initialIsSettingsAdmin = true
                                )
                            }
                        }
                    }
                }
            }
        }

        // Global Command Palette Modal (Section 32)
        if (isCommandPaletteOpen) {
            CommandPaletteDialog(
                searchQuery = globalSearchQuery,
                onSearchChange = { studioViewModel.updateGlobalSearch(it) },
                onSelectDestination = { studioViewModel.navigateTo(it) },
                onQuickAction = { code ->
                    when (code) {
                        "COMPLETE_VIDEO" -> studioViewModel.runOneClickCompleteVideo()
                        "DIRECTOR" -> studioViewModel.navigateTo(StudioDestination.AI_DIRECTOR)
                        "AUTO_EDIT" -> {
                            studioViewModel.navigateTo(StudioDestination.STUDIO)
                            studioViewModel.runAutoEditor()
                        }
                        "VIRAL" -> {
                            studioViewModel.navigateTo(StudioDestination.STUDIO)
                            studioViewModel.analyzeProjectForViralMode()
                        }
                        "ADD_SCENE" -> {
                            studioViewModel.navigateTo(StudioDestination.AI_DIRECTOR)
                            studioViewModel.addNewSceneToActiveProject()
                        }
                        "TIMELINE" -> studioViewModel.navigateTo(StudioDestination.STUDIO)
                        "EXPORT" -> studioViewModel.navigateTo(StudioDestination.EXPORTS)
                    }
                },
                onDismiss = { studioViewModel.setCommandPaletteOpen(false) }
            )
        }

        // Credit Cost Estimation Confirmation Dialog (Section 61)
        pendingCreditAction?.let { action ->
            CreditEstimationConfirmationDialog(
                pendingAction = action,
                currentBalance = currentCredits,
                onConfirm = { studioViewModel.confirmPendingCreditAction() },
                onDismiss = { studioViewModel.dismissPendingCreditAction() }
            )
        }

        // Global Queue & Notifications Sheet (Section 26 & 44)
        if (isNotificationSheetOpen) {
            NotificationsAndQueueDialog(
                jobs = allJobs,
                notifications = notifications,
                onRetryJob = { studioViewModel.retryJob(it) },
                onMarkAllRead = { studioViewModel.markAllNotificationsRead() },
                onDismiss = { studioViewModel.setNotificationSheetOpen(false) }
            )
        }

        // Phase 1 Architecture Audit & Phase 2 Design System Modal
        if (isArchitectureAuditOpen) {
            ArchitectureAuditModal(
                onDismiss = { studioViewModel.setArchitectureAuditOpen(false) }
            )
        }
    }
}
